<?php $__env->startSection('content'); ?>
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="container" id="kt_content_container">
            <div class="row g-5 gx-xxl-8 mb-xxl-3">
                <div class="col-xxl-5">
                    <div class="card card-xxl-stretch">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <form method="POST" action="<?php echo e(route('instructorcourses.add')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="InstructorID" class="required form-label">Instructor</label>
                                    <select name="InstructorID" class="form-control form-control-solid <?php $__errorArgs = ['InstructorID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Select an Instructor</option>
                                        <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($instructor->id); ?>"><?php echo e($instructor->FirstName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['InstructorID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="CourseID" class="required form-label">Course</label>
                                    <select name="CourseID" class="form-control form-control-solid <?php $__errorArgs = ['CourseID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Select a Course</option>
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($course->CourseID); ?>"><?php echo e($course->CourseName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['CourseID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary mt-2"><?php echo e(isset($instructorCourse) ? 'Update' : 'Create'); ?>

                                        Instructor Course</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-7">
                    <div class="card card-xxl-stretch mb-5 mb-xxl-8">
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-boldest fs-3 text-dark">Instructor Courses</span>
                            </h3>
                        </div>
                        <div class="card-body">
                            <?php if(count($instructorCourses) > 0): ?>
                                <table class="table table-row-dashed table-row-gray-300 gy-7">
                                    <thead>
                                        <tr class="fw-bolder fs-6 text-gray-800">
                                            <th>Instructor</th>
                                            <th>Course</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $instructorCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructorCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($instructorCourse->instructor->name); ?></td>
                                                <td><?php echo e($instructorCourse->course->title); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('instructorcourses.edit', $instructorCourse->InstructorCourseID)); ?>"
                                                        class="btn btn-sm btn-primary"><i class="fas fa-pen-nib"></i></a>
                                                    <a href="<?php echo e(route('instructorcourses.delete', $instructorCourse->InstructorCourseID)); ?>"
                                                        class="btn btn-sm btn-danger"><i class="las la-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No Instructor Courses available.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Biologyapp\resources\views/Instructorcourses/index.blade.php ENDPATH**/ ?>