<?php $__env->startSection('content'); ?>
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Container-->
        <div class="container" id="kt_content_container">
            <!--begin::Row-->
            <div class="row g-5 gx-xxl-8 mb-xxl-3">
                <div class="col-xxl-12">
                    <!--begin::Chart Widget 1-->
                    <div class="card card-xxl-stretch mb-5 mb-xxl-8">
                        <!--begin::Card header-->
                        <div class="card-header border-0 pt-5">
                            <!--begin::Card title-->
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-boldest fs-3 text-dark">Courses</span>
                            </h3>
                            <!--end::Card title-->
                        </div>
                        <!--end::Header-->
                        <!--begin::Card body-->
                        <div class="card-body ">
                            <?php if(count($courses) > 0): ?>
                                <table class="table table table-row-dashed table-row-gray-300 gy-7">
                                    <thead>
                                        <tr class="fw-bolder fs-6 text-gray-800">
                                            <th>CourseName</th>
                                            <th>Description</th>
                                            <th>InstructorID</th>
                                            <th>StartDate</th>
                                            <th>EndDate</th>
                                            <th>Price</th>
                                            <th>Level</th>
                                            <th>IsActive</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses23): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($courses23->CourseName); ?></td>
                                                <td><?php echo e($courses23->Description); ?></td>
                                                <td><?php echo e($courses23->InstructorID); ?></td>
                                                <td><?php echo e($courses23->StartDate); ?></td>
                                                <td><?php echo e($courses23->EndDate); ?></td>
                                                <td><?php echo e($courses23->Price); ?></td>
                                                <td><?php echo e($courses23->Level); ?></td>
                                                <td><?php echo e($courses23->IsActive); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('courses.upload', $courses23->CourseID)); ?>"
                                                        class="btn btn-success btn-sm">Upload</a>
                                                    <a href="<?php echo e(route('courses.files', $courses23->CourseID)); ?>"
                                                        class="btn btn-warning btn-sm">Files</a>
                                                    <a href="<?php echo e(route('courses.edit', $courses23->CourseID)); ?>"
                                                        class="btn btn-sm btn-primary">Edit</a>
                                                    <a href="<?php echo e(route('courses.delete', $courses23->CourseID)); ?>"
                                                        class="btn btn-danger btn-sm">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No courses available.</p>
                            <?php endif; ?>
                        </div>
                        <!--end::Card body-->
                    </div>
                    <!--end::Chart Widget 1-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Biologyapp\resources\views/courses/index.blade.php ENDPATH**/ ?>